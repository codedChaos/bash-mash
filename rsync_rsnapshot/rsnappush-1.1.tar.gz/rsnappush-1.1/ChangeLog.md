# ChangeLog

## 1.1
* snapshots permissions from getfacl(1)
* wrote a manpage
* Switched to Mozilla Public License
